Here you can store any scripts you use to benchmark and time your code.
